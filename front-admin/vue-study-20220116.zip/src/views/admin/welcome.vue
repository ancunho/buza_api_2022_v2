<template>
  <div>
    <h4>welcome</h4>
  </div>
</template>

<script>
export default {
  name: "welcome"
}
</script>

<style scoped>

</style>