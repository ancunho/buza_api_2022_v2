package com.buza.server.dao;

import com.buza.server.dto.SysMenuDto;
import com.buza.server.entity.SysMenu;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RoleMenuMapper {

    public List<SysMenuDto> getAllSysMenuList();

}
