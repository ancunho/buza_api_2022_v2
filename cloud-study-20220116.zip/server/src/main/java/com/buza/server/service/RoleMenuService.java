package com.buza.server.service;

import com.buza.server.dto.SysMenuDto;
import com.buza.server.entity.SysMenu;
import com.buza.server.entity.SysRole;

import java.util.List;
import java.util.Map;

public interface RoleMenuService {

    public List<SysMenuDto> getAllSysMenuList();
    public List<SysRole> getAllSysRoleList();

    public Boolean existMenuName(Map<String, Object> mapParams);
    public Boolean insertSysMenu(SysMenu sysMenu);
    public Boolean updateSysMenu(SysMenu sysMenu);

}
