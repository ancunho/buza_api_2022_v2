package com.buza.server.service.impl;

import com.buza.server.dao.RoleMenuMapper;
import com.buza.server.dao.SysMenuMapper;
import com.buza.server.dao.SysRoleMapper;
import com.buza.server.dto.SysMenuDto;
import com.buza.server.entity.SysMenu;
import com.buza.server.entity.SysRole;
import com.buza.server.service.RoleMenuService;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Slf4j
@Getter
@Setter
@AllArgsConstructor
@Service
public class RoleMenuServiceImpl implements RoleMenuService {

    @Resource
    private RoleMenuMapper roleMenuMapper;

    @Resource
    private SysRoleMapper sysRoleMapper;

    @Resource
    private SysMenuMapper sysMenuMapper;

    public List<SysMenuDto> getAllSysMenuList() {
        return roleMenuMapper.getAllSysMenuList();
    }

    public List<SysRole> getAllSysRoleList() {
        return sysRoleMapper.getAllSysRoleList();
    }

    public Boolean existMenuName(Map<String, Object> mapParams) {
        Integer existMenuName = sysMenuMapper.existMenuName(mapParams);
        if (existMenuName == null) {
            return false; // menuName不存在
        }
        return true;
    }

    public Boolean insertSysMenu(SysMenu sysMenu) {
        int insertCount = sysMenuMapper.insertSelective(sysMenu);
        if (insertCount > 0) {
            return true;
        }
        return false;
    }

    public Boolean updateSysMenu(SysMenu sysMenu) {
        int updateCount = sysMenuMapper.updateByPrimaryKeySelective(sysMenu);
        if (updateCount > 0) {
            return true;
        }
        return false;
    }


}
