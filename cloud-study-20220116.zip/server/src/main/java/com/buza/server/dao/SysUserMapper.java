package com.buza.server.dao;

import com.buza.server.entity.SysUser;

public interface SysUserMapper {
    int deleteByPrimaryKey(Integer userSeq);

    int insert(SysUser record);

    int insertSelective(SysUser record);

    SysUser selectByPrimaryKey(Integer userSeq);

    int updateByPrimaryKeySelective(SysUser record);

    int updateByPrimaryKey(SysUser record);
}