package com.buza.system.controller;

import com.buza.server.common.ResponseCode;
import com.buza.server.common.ServerResponse;
import com.buza.server.dto.SysMenuDto;
import com.buza.server.entity.SysMenu;
import com.buza.server.service.RoleMenuService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping(value = "/config")
public class RoleMenuController {

    @Autowired
    private RoleMenuService roleMenuService;

    @GetMapping("/menu/list")
    public ServerResponse<List<SysMenuDto>> getAllSysMenuList() {
        List<SysMenuDto> getAllSysMenuList = roleMenuService.getAllSysMenuList();
        return ServerResponse.createBySuccess(getAllSysMenuList);
    }

    @PostMapping("/menu/modify")
    public ServerResponse modifySysMenu(@RequestBody SysMenuDto sysMenuDto) {
        if (StringUtils.isEmpty(sysMenuDto.getName())
            || StringUtils.isEmpty(String.valueOf(sysMenuDto.getType()))
            || StringUtils.isEmpty(sysMenuDto.getStatus())
        ) {
            return ServerResponse.createByErrorCodeMessage(ResponseCode.ILLEGAL_ARGUMENT.getCode(), ResponseCode.ILLEGAL_ARGUMENT.getDesc());
        }

        if (sysMenuDto.getId() == null || String.valueOf(sysMenuDto.getId()) == "") {
            // insert New
            // 1. check menu name repeat
            Map<String, Object> mapParams = new HashMap<>();
            mapParams.put("menuName", sysMenuDto.getName());
            boolean isExistMenuName = roleMenuService.existMenuName(mapParams);
            if (isExistMenuName) {
                return ServerResponse.createByErrorMessage("菜单名重复, 请使用其他菜单名称");
            }

            SysMenu sysMenu = new SysMenu();
            sysMenu.setName(sysMenuDto.getName());
            sysMenu.setParentId((sysMenuDto.getParentId() == null || String.valueOf(sysMenuDto.getParentId()) == "") ? 0 : sysMenuDto.getParentId());
            sysMenu.setStatus(sysMenuDto.getStatus());
            sysMenu.setPath(sysMenuDto.getPath());
            sysMenu.setPerms(sysMenuDto.getPerms());
            sysMenu.setComponent(sysMenuDto.getComponent());
            sysMenu.setType(sysMenuDto.getType());
            sysMenu.setIcon(sysMenuDto.getIcon());
            sysMenu.setOrderNum(sysMenuDto.getOrderNum());
            sysMenu.setOption01(sysMenuDto.getOption01());
            sysMenu.setOption02(sysMenuDto.getOption02());
            sysMenu.setOption03(sysMenuDto.getOption03());
            sysMenu.setOption04(sysMenuDto.getOption04());
            sysMenu.setOption05(sysMenuDto.getOption05());
            boolean isSuccessInsert = roleMenuService.insertSysMenu(sysMenu);
            if (isSuccessInsert) {
                return ServerResponse.createBySuccessMessage("新增成功");
            }
            return ServerResponse.createByErrorMessage("新增失败");
        } else {
            // modify origin
            Map<String, Object> mapParams = new HashMap<>();
            mapParams.put("menuName", sysMenuDto.getName());
            mapParams.put("menuId", sysMenuDto.getId());
            boolean isExistMenuName = roleMenuService.existMenuName(mapParams);
            if (isExistMenuName) {
                return ServerResponse.createByErrorMessage("菜单名重复, 请使用其他菜单名称");
            }

            SysMenu sysMenu = new SysMenu();
            sysMenu.setId(sysMenuDto.getId());
            sysMenu.setName(sysMenuDto.getName());
            sysMenu.setParentId((sysMenuDto.getParentId() == null || String.valueOf(sysMenuDto.getParentId()) == "") ? 0 : sysMenuDto.getParentId());
            sysMenu.setStatus(sysMenuDto.getStatus());
            sysMenu.setPath(sysMenuDto.getPath());
            sysMenu.setPerms(sysMenuDto.getPerms());
            sysMenu.setComponent(sysMenuDto.getComponent());
            sysMenu.setType(sysMenuDto.getType());
            sysMenu.setIcon(sysMenuDto.getIcon());
            sysMenu.setOrderNum(sysMenuDto.getOrderNum());
            sysMenu.setOption01(sysMenuDto.getOption01());
            sysMenu.setOption02(sysMenuDto.getOption02());
            sysMenu.setOption03(sysMenuDto.getOption03());
            sysMenu.setOption04(sysMenuDto.getOption04());
            sysMenu.setOption05(sysMenuDto.getOption05());

            boolean isSuccessUpdate = roleMenuService.updateSysMenu(sysMenu);
            if (isSuccessUpdate) {
                return ServerResponse.createBySuccessMessage("更新成功");
            }
            return ServerResponse.createByErrorMessage("更新失败");
        }
    }

}
